Front end tests are done using cypress. All tests are contained in the e2e file.
Install cypress using "npm install cypress --save-dev".
Install libraries using "npm install --save-dev cypress-file-upload".
Open cypress using "npx cypress open".
Follow configuration steps given by cypress.
