const login = require("../register.js");


test("should reject names longer than 16 chars", () => {
    expect(login("thisnameismorethansixteenchars", "validpass", "validpass"))
        .toBe("Username cannot exceed 16 characters");
});

test("should reject names with illegal characters", () => {
    expect(login("vali|dna<me", "validpass", "validpass"))
        .toBe("Username cannot contain special characters: /\\|<>=&#");
});

test("should reject if passwords don't match", () => {
    expect(login("validname", "validpass", "differentpass"))
        .toBe("Passwords do not match");
});

//Null field tests
test("should reject if name is blank", () => {
    expect(login("", "validpass", "differentpass"))
        .toBe("Please fill all fields");
});

test("should reject if name is blank", () => {
    expect(login("validname", "", "validpass"))
        .toBe("Please fill all fields");
});

test("should reject if name is blank", () => {
    expect(login("validname", "validpass", ""))
        .toBe("Please fill all fields");
});

test("should reject if name is blank", () => {
    expect(login("", "", ""))
        .toBe("Please fill all fields");
});
//Null Field tests

test("should accept valid name and password", () => {
    expect(login("validname", "validpass", "validpass"))
        .toBe("Welcome validname");
});
