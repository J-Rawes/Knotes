function login(username, password, password2) {

    let isHTML = (username === undefined && password === undefined && password2 === undefined); //if no arguements are passed it is being run through the browser

    //If opened via the browser, grab values from fields
    if (isHTML) {
        var form = document.forms["logIn"];
        if (!form) {
            console.error("Error: Cannot find 'logIn' form.");
            return false; 
        }

        username = form.user.value;
        password = form.password.value;
        password2 = form.password2.value;
    }

    var conditions = ["\\", "<", ">", "|", "/", "=", "&", "#"];
    let message = "";

    //These variables depend on if the parameters have been changed by the above if statement
    if (!username || !password || !password2) {
        message = "Please fill all fields";
    } else if (username.length > 16) {
        message = "Username cannot exceed 16 characters";
    } else if (conditions.some(el => username.includes(el))) {
        message = "Username cannot contain special characters: /\\|<>=&#";
    } else if (password.length > 16) {
        message = "Password cannot exceed 16 characters";
    } else if (conditions.some(el => password.includes(el))) {
        message = "Password cannot contain special characters: /\\|<>=&#";
    } else if (password !== password2) {
        message = "Passwords do not match";
    } else {
        message = "Welcome " + username;
    }

    // If running in HTML, update the UI
    if (isHTML) {
        let messageElement = document.getElementById("message");
        if (messageElement) {
            messageElement.innerHTML = message;
            messageElement.style.color = message.includes("Welcome") ? "black" : "red";
        }
        return false; // Prevents form submission in HTML
    }

    return message; //For Jest testing...this is passed to the test file and is compared for validity
}

// Export for Jest testing
if (typeof module !== "undefined" && module.exports) {
    module.exports = login;
}
