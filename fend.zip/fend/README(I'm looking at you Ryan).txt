Steps:

- cd to this project file (fend)
- npm install
- to run tests: npm test
